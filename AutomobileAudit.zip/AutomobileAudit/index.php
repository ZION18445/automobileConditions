<!DOCTYPE html>
<html>
    <head>      
        <meta charset="UTF-8">
        <title>Automobile Audit</title>  
        <link href="library/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <link href="css/styles.css" rel="stylesheet" type="text/css"/>
        <link href="library/Datatable/dataTables.bootstrap5.min.css" rel="stylesheet" type="text/css"/>
        <link href="library/Datatable/jquery.dataTables.min.css" rel="stylesheet" type="text/css"/>
        <link href="library/Datatable/jquery.dataTables_themeroller.css" rel="stylesheet" type="text/css"/>
        <link href="library/Datatable/dataTables.jqueryui.css" rel="stylesheet" type="text/css"/>
        <link href="library/Datatable/buttons.dataTables.min.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
        <div class="container ">
            <div class="card bg-white">
                <div class="card-header" id="header">

                </div>
                <div class="card-body col-sm-8">
                    <div class="row">
                        <div class="col ">
                            <div id="formDiv ">
                                <!--form to take inputs from customers of car issues-->
                                <form>
                                    <div class="form-group">
                                        <label>Full Name</label>  
                                        <input type="text" placeholder="Enter full name" class="col-sm-12 form-control" id="fullname">
                                    </div>  
                                    <div class="form-group">
                                        <label>Reference Code</label>  
                                        <input type="text" placeholder="Enter reference code" class="col-sm-12 form-control" id="reference">
                                    </div>
                                    <div class="form-group">
                                        <label>Email address</label>  
                                        <input type="text" placeholder="Enter email" class="col-sm-12 form-control" id="email">
                                    </div>
                                    <div class="form-group">
                                        <label>Automobile Maker</label>  
                                        <select class="col-sm-12 form-control" id="array">

                                        </select>
                                    </div>
                                    <div class="form-group" id="modelDiv">
                                        <label>Models</label>  
                                        <select class="col-sm-12 form-control" id="models">

                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label id="check">Car conditions:</label><br>  
                                        <label class="checkbox"><input type="checkbox"name="Engine issue"  value="" id="engine">Engine issue
                                        </label><br>
                                        <label class="checkbox"><input type="checkbox" name="Gearbox issue"  value="" id="gearbox">Gearbox issue</label><br>
                                        <label class="checkbox"><input type="checkbox"  name="Need body repair" value=""  id="body">Need body repair</label><br>
                                        <label class="checkbox"><input type="checkbox" name="Need repainting"  value="" id="need">Need repainting</label><br>
                                        <label class="checkbox"><input type="checkbox" name="Wiring problems"  value="" id="problem">Wiring problems</label><br>
                                        <label class="checkbox"><input type="checkbox" name="Oil leakage" value="" id="oil">Oil leakage</label><br>
                                        <label class="checkbox"><input type="checkbox" name="Brake issue"  value="" id="brake">Brake issue</label>
                                    </div>
                                    <div class="form-group">
                                        <button type="button" class="btn btn-block btn-info" id="next">
                                            Next
                                        </button>
                                    </div>
                                </form>                                 
                            </div>
                        </div>                      
                    </div>
                </div>
                <div id="myeditor"></div>
                <div class="card-footer">

                </div>
            </div>
        </div>
        <script src="library/jquery-3.5.1/jquery-3.5.1.min.js" type="text/javascript"></script>
        <a href="library/jquery-3.5.1/jquery-3.5.1.min.map"></a>
        <script src="library/jquery-3.5.1/popper.min.js" type="text/javascript"></script>
        <script src="library/notify/notify.min.js" type="text/javascript"></script>
        <script src="library/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
        <script src="library/Datatable/jquery.dataTables.min.js" type="text/javascript"></script>       
        <script src="js/script.js" type="text/javascript"></script>
    </body>
</html>

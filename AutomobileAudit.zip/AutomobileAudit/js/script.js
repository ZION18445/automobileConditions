$(function () {
    
     
// Targeting the select tag and creating an array to pupulate the select tag
    var elements = ["Toyota", "Nissan", "Ford", "Volkswagen", "Hyundai", "Honda", "Suzuki", "Daimler", "Kia", "BMW"];
    var elements2 = [{"Toyota": ["Camry", "Avalon", "Corolla", "Prius", "Yaris"]},
        {"Nissan": ["Altima", "Maxima", "Murano", "NV Cargo", "Armada"]},
        {"Ford": ["Fiesta", "Focus", "Figo", "Escort", "Mondeo"]},
        {"Volkswagen": ["Arteon", "Atlas", "Beetle", "Eos", "Golf"]},
        {"Hyundai": ["Aura", "Accent", "Santro", "i30", "Celesta"]},
        {"Honda": ["Civic", "Brio", "City", "Accord", "Amaze"]},
        {"Suzuki": ["Swift", "Alto", "Celerio", "Jimmy", "SX4"]},
        {"Daimler": ["Mercedes-Benz", "Mercedes-AMG", "Mercedes-Maybach", "Smart", "V-Class"]},
        {"Kia": ["Optima", "Rio", "Soul", "Forte", "Sedona"]},
        {"BMW": ["X3 M", "X5 PHEV", "X4", "X3", "X5"]}
    ];
    
//                looping through the array for car makers to fill the dropdown for automobile makers
    $("#array").empty().append('<option value="" >--Select Car--</option>');
    $.each(elements, function (key, value) {
        $("#array").append('<option value=' + value.split(" ") + '>' + value + '</option>');
    })
    $("#array").on('change', function () {
        if ($(this).val() === '') {
            $("#models").empty();
        } else {
            $("#models").empty().append('<option value="">--select model--<option>');
            var cartype = $(this).val();
            getcar(cartype, elements2);
            $('option[value=""],option:not([value])').remove();
        }
    });
    
//             function used to fill in the models for each automodile maker chosen
    function getcar(data, elements2) {
        if (data === "Toyota") {
            modeldata = "";
            $.each(elements2, function (key, value) {
                $.each(value.Toyota, function (key, value) {
                    $("#models").append('<option value=' + value + '>' + value + '<option>');
                });
            });
            
//                    return 'Toyota';
        } else if (data === "Nissan") {
            $.each(elements2, function (key, value) {
                $.each(value.Nissan, function (key, value) {
                    $("#models").append('<option value=' + value + '>' + value + '<option>');
                });
            });
        } else if (data === "Ford") {
            $.each(elements2, function (key, value) {
                $.each(value.Ford, function (key, value) {
                    $("#models").append('<option value=' + value + '>' + value + '<option>');
                });
            });
        } else if (data === "Volkswagen") {
            $.each(elements2, function (key, value) {
                $.each(value.Volkswagen, function (key, value) {
                    $("#models").append('<option value=' + value + '>' + value + '<option>');
                });
            });
        } else if (data === "Hyundai") {
            $.each(elements2, function (key, value) {
                $.each(value.Hyundai, function (key, value) {
                    $("#models").append('<option value=' + value + '>' + value + '<option>');
                });
            });
        } else if (data === "Honda") {
            $.each(elements2, function (key, value) {
                $.each(value.Honda, function (key, value) {
                    $("#models").append('<option value=' + value + '>' + value + '<option>');
                });
            });
        } else if (data === "Suzuki") {
            $.each(elements2, function (key, value) {
                $.each(value.Suzuki, function (key, value) {
                    $("#models").append('<option value=' + value + '>' + value + '<option>');
                });
            });
        } else if (data === "Daimler") {
            $.each(elements2, function (key, value) {
                $.each(value.Daimler, function (key, value) {
                    $("#models").append('<option value=' + value + '>' + value + '<option>');
                });
            });
        } else if (data === "Kia") {
            $.each(elements2, function (key, value) {
                $.each(value.Kia, function (key, value) {
                    $("#models").append('<option value=' + value + '>' + value + '<option>');
                });
            });
        } else if (data === "BMW") {
            $.each(elements2, function (key, value) {
                $.each(value.BMW, function (key, value) {
                    $("#models").append('<option value=' + value + '>' + value + '<option>');
                });
            });
        } else {
            $("#models").empty();
        }
    }



// Next button click performs validation with functions called to perform operation
    $("#next").click(function () {

//              validating if inputs are empty or not using by calling functions
        if ($("#fullname").val() === "" || $("#reference").val() === "" || $("#email").val() === "" || $("#array").val() === "" || $("#models").val() === "" || $("input[type='checkbox']").not(":checked")) {
            validateIfEmpty($("#fullname"), "Full Name Empty");
            validateIfEmpty($("#reference"), "Reference Empty");
            validateIfEmpty($("#email"), "Email Empty");
            validateIfEmpty($("#array"), "Maker Empty");
            validateIfEmpty($("#models"), "Models Empty");
            validateCheckbox($("input[type='checkbox']"), "No checkbox chosen");
        }

        //              validating reference code, email, fullname to make sure they meet adequate criteria
        if ($("#reference").val().length < 6 && $("#reference").val() !== "") {
            $("#reference").notify("Minimum of 6 characters", "error");
        } else if ($("#reference").val().match(/[0-9]/) === null && $("#reference").val() !== "") {
            $("#reference").notify("Must contain number", "error");
        } else if ($("#reference").val().match(/[a-z]/) === null && $("#reference").val() !== "") {
            $("#reference").notify("Must contain lower character", "error");
        } else if ($("#reference").val().match(/[A-Z]/) === null && $("#reference").val() !== "") {
            $("#reference").notify("Must contain upper character", "error");
        } else if ($("#reference").val().match(/([!,%,&,@,#,$,^,*,?,_,~,.,\,/,-,+,=,<,>,(,),|,``,(,)])/) === null && $("#reference").val() !== "") {
            $("#reference").notify("Must contain special character", "error");
        } else if ($("#email").val().match(/^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/) === null && email !== "") {
            $("#email").notify("Enter valid email", "error");
        } 


//              checking if all conditions are met and sending data to a php file
        if ($("#fullname").val() !== "" !== null && $("#reference").val().length > 5 && $("#reference").val() !== "" && $("#reference").val().match(/[0-9]/) !== null && $("#reference").val().match(/[a-z]/) !== null
                && $("#reference").val().match(/[A-Z]/) !== null && $("#reference").val().match(/([!,%,&,@,#,$,^,*,?,_,~,.,\,/,-,+,=,<,>,(,),|,``,(,)])/) !== null && $("#email").val().match(/^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/) !== null && email !== ""
                && $("#array").val() !== "" && $("#models").val() !== "" && $("input[type='checkbox']").is(":checked")) {

            var fullname = $("#fullname").val();
             fullname.trim();
            if(fullname.length > 30){
                
                fullname = fullname.substring(0,30) + "...";
            }
            console.log(fullname);

            var reference = $("#reference").val();
            var maker = $("#array").val();
            var model = $("#models").val();
            var email = $("#email").val();
            TakeCheckbox($("#engine"));
            TakeCheckbox($("#gearbox"));
            TakeCheckbox($("#body"));
            TakeCheckbox($("#need"));
            TakeCheckbox($("#problem"));
            TakeCheckbox($("#oil"));
            TakeCheckbox($("#brake"));

            var issues = [TakeCheckbox($("#engine")), TakeCheckbox($("#gearbox")), TakeCheckbox($("#body")),
                TakeCheckbox($("#need")), TakeCheckbox($("#problem")), TakeCheckbox($("#oil")), TakeCheckbox($("#brake"))];
            var newissues = issues.filter(function (value) {
                return value !== "";
            });

       
    
//            posting to php file
            $.post("php/saved.php", {
               // json: JSON.stringify(data)
                fullname: fullname,
                reference: reference,
                maker: maker,
                model: model,
                email: email,
                newissues: newissues
            }, function (data) {
                 console.log(data);
            });
             
        }


          window.location.href = "AuditPreview.php";
    });


   
    // fetching customer data from the database to a datatable and also showing a object at the console
$.post("php/fetch.php", {
       
    }, function (data) {
        var newdata = JSON.parse(data);

         $.each(newdata, function (key, value) {
                var customer = {
                    name: value.Fullname,
                    email: value.email,
                    refcode: value.reference,
                    make: value.maker,
                    model: value.model,
                    conditions: value.issues
                };
                $("#btn").click(function () {
                 console.log(customer);
            });
             });
            $("#profile").DataTable({
                responsive: true,
                paging: true,
                destroy: true,
                stateSave: true,
                data: newdata,
                columns: [
                    {data: "Fullname"},
                    {data: "reference"},
                    {data: "email"},
                    {data: "maker"},
                    {data: "model"},
                    {data: "issues"}               
                  ]
            });
            
//           

        });



}); 

 // function used to validate if inputs are empty or not
    function validateIfEmpty(selector, message) {
        var input = selector.val();
        if (input === "" || input === null) {
            selector.notify(message, "error");
        } else if (input !== "") {
            selector.notify("Valid", "success");
        }
    }

    // function to validate checkboxes

    function validateCheckbox(selector, message) {

        if (selector.is(":checked")) {
            $("#check").notify("Valid", "success");
            $("#check").focus();
//            console.log(selector.attr('name'));
            //   return selector.attr('name');
        } else {
            $("#check").notify(message, "error");
            $("#check").focus();
            //  return '';
        }

    }

    function TakeCheckbox(selector) {

        if (selector.is(":checked")) {

            return selector.attr('name');
        } else {
            return '';
        }

    }

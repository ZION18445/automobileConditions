<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
    <a href="php/dbconnect.php"></a>
        <title>Preview</title>
        <!--links for bootstrap, jQuery, css and javascript links usef-->
        <link href="library/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <link href="css/styles.css" rel="stylesheet" type="text/css"/>
        <link href="library/Datatable/dataTables.bootstrap5.min.css" rel="stylesheet" type="text/css"/>
        <link href="library/Datatable/jquery.dataTables_themeroller.css" rel="stylesheet" type="text/css"/>
        <link href="library/Datatable/buttons.dataTables.min.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
        <div class="container" id="sheet">       
            <div class="row" id="preview">
           <div class="col-lg-12">
            <!--table to view data-->
            <table id="profile" class="table-bordered" style="width:100%;">
                <thead>
                    <tr>
                        <th>Full name</th>
                        <th>Reference code</th>
                        <th>Email</th>
                        <th>Automobile Maker</th>
                        <th>Model</th>
                        <th>Car issues</th>
                    </tr>
                </thead>

                </table>  
            </div>
        </div>
            <div class="form-group ml-auto"id="btn">
            <button type="button" class="btn btn-lg btn-success" id="next">
                Submit
            </button>
            </div>
            </div>
    </div> 
        <script src="library/jquery-3.5.1/jquery-3.5.1.min.js" type="text/javascript"></script>
        <a href="library/jquery-3.5.1/jquery-3.5.1.min.map"></a>
        <script src="library/jquery-3.5.1/popper.min.js" type="text/javascript"></script>
        <script src="library/notify/notify.min.js" type="text/javascript"></script>
        <script src="library/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
        <script src="library/Datatable/jquery.dataTables.min.js" type="text/javascript"></script>       
        <script src="js/script.js" type="text/javascript"></script>
    </body>
</html>

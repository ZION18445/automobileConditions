
<?php

include 'dbconnect.php';

//$data = json_decode($_POST['json']);
//$myprofileEncoded = json_encode($data);
//file_put_contents("audit.data", $myprofileEncoded);
//$fileContent = file_get_contents("audit.data");


// collecting data from post in js file
$fullname = $_POST['fullname'];
$reference = $_POST['reference'];
$maker = $_POST['maker'];
$model = $_POST['model'];
$email = $_POST['email'];

//$newissues = $_POST['newissues'];
//file_put_contents("audit.txt", $newissues);
//$newdata = file_get_contents("audit.txt");


// inserting data into the database
$newissues = implode(',',$_POST['newissues']);

$insert =executequery("INSERT INTO customers ( Fullname, reference, email, maker,model,issues) VALUES('$fullname','$reference','$email','$maker','$model','$newissues')");

if ($insert == true) {
    print json_encode(true);
} else {
    print json_encode(false);
}
